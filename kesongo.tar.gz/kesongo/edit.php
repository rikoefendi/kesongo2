<?php
  include'core/init.php';
  $id  = Input::get('chk');
  $jml = count(Input::get('chk'));
  if(Input::get('edit')){
    if($jml>0){
      for($i=1; $i<=$jml; $i++){
        $ib = $id[$i];
        $update->update_barang(array(
                              "kode_barang"     => Input::get('kode_barang'.$i),
                              "nama_barang"     => Input::get('nama_barang'.$i),
                              "id_items"        => Input::get('id_items'.$i),
                              "h_beli"          => Input::get('h_beli'.$i),
                              "h_jual"          => Input::get('h_jual'.$i),
                              "laba"            => Input::get('h_jual'.$i)-Input::get('h_beli'.$i),
                              "s_beli"          => Input::get('s_beli'.$i)
                          ));
      }
    }
    var_dump($jml);
    die();
  }
  $v = $view->get_items();
  include'templates/header.php';
?>

  <div class="konten">
    <div class="table">
      <h2>Tambah Stok</h2>
      <div class="line"></div>
        <form class="" action="edit.php" method="post">
          <table class="tambah" id="tambah">
            <tr>
              <th>No.</th>
              <th>Kode Barang</th>
              <th>Nama Barang</th>
              <th>Jenis Barang</th>
              <th>Harga Beli</th>
              <th>Harga Jual</th>
              <th>stok Beli</th>
            </tr>
              <?php
                $no=1;
                for ($i=1;  $i <= $jml; $i++) {
                  foreach ($v as $key => $items) {
                    $id_items = $items->id_items;

                    $b = $view->get_data("WHERE id_barang=".$id[$i]);
                      foreach ($b as $key => $barang) {
              ?>
              <tr class="even">
                <td><?php echo $no; ?></td>
                <td><input type="hidden" name="kode_barang<?php echo $i; ?>" value="<?php echo $barang->kode_barang; ?>"><?php echo $barang->kode_barang; ?></td>
                <td><input type="text" name="nama_barang<?php echo $i; ?>" value="<?php echo $barang->nama_barang; ?>"></td>
                <td><input type="hidden" name="id_items<?php echo $i; ?>" value="<?php echo $barang->$id_items; ?>"><?php echo $items->nama_items; ?></td>
                <td><input type="text" name="h_beli<?php echo $i; ?>" value="<?php echo $barang->h_beli; ?>"></td>
                <td><input type="text" name="h_jual<?php echo $i; ?>" value="<?php echo $barang->h_jual; ?>"></td>
                <td><input type="text" name="s_beli<?php echo $i; ?>" value="<?php echo $barang->s_beli; ?>"></td>
              </tr>
            <?php $no++; }}} ?>
            <tr>
              <td rowspan="7"><input type="submit" name="edit" value="Simapn" align="right"></td>
            </tr>
          </table>
      </form>
    </div>
  </div>

<?php
  include 'templates/footer.php';
?>
