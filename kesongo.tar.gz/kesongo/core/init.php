<?php
spl_autoload_register(function($nama){
  include'clasess/'.$nama.'.php';
});
$view = new view();
$insert = new insert();
$delete = new delete();
$update = new update();
?>
