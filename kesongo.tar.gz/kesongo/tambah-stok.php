  <?php
    include'core/init.php';
    if(Input::get('tambah_stok')){
      $total = Input::get('total');
      for($i=1; $i <= $total; $i++){
        if($insert->tambah_stok(array(
                              "kode_barang"     => Input::get('kode_barang'.$i),
                              "nama_barang"     => Input::get('nama_barang'.$i),
                              "id_items"        => Input::get('id_items'.$i),
                              "h_beli"          => Input::get('h_beli'.$i),
                              "h_jual"          => Input::get('h_jual'.$i),
                              "laba"            => Input::get('h_jual'.$i)-Input::get('h_beli'.$i),
                              "s_beli"          => Input::get('s_beli'.$i)
                          ))){
                            header('location: index.php');
                          };
      }
    }
    $v = $view->get_items();
    $b = $view->get_data();
    foreach ($b as $key => $data) {
      $kode = $data->kode_barang;
    }
    if(empty($kode)){
      $noUrut = 1;
    }else{
    $noUrut = substr($kode,4);
    $noUrut++;
  }
    $char="BA-";
    $newID = $char.sprintf("%04s", $noUrut);
    include'templates/header.php';
    if(Input::get('subfor')){
  ?>

    <div class="konten">
      <div class="table">
        <h2>Tambah Stok</h2>
        <div class="line"></div>
          <form class="" action="tambah-stok.php" method="post">
            <table class="tambah" id="tambah">
              <tr>
                <th>No.</th>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Jenis Barang</th>
                <th>Harga Beli</th>
                <th>Harga Jual</th>
                <th>stok Beli</th>
              </tr>
                <?php
                  $no=1;
                  for ($i=1;  $i <= Input::get('for'); $i++) {
                  echo "<input type='hidden' name='total' value='".Input::get('for')."'>";
                ?>
                <tr class="even">
                  <td><?php echo $no; ?></td>
                  <td><input type="hidden" name="kode_barang<?php echo $i; ?>" value="<?php echo $newID; ?>"><?php echo $newID++; ?></td>
                  <td><input type="text" name="nama_barang<?php echo $i; ?>" value=""></td>
                  <td>
                      <select class="" name="id_items<?php echo $i; ?>">
                          <option value="">------</option>
                        <?php
                            foreach ($v as $key => $items) {
                            ?>
                            <option value="<?php echo $items->id_items; ?>"><?php echo $items->nama_items; ?></option>
                            <?php
                            }
                          ?>
                      </select>
                  </td>
                  <td><input type="text" name="h_beli<?php echo $i; ?>" value=""></td>
                  <td><input type="text" name="h_jual<?php echo $i; ?>" value=""></td>
                  <td><input type="text" name="s_beli<?php echo $i; ?>" value=""></td>
                </tr>
              <?php $no++; } ?>
              <tr>
                <td rowspan="7"><input type="submit" name="tambah_stok" value="Tambah" align="right"></td>
              </tr>
            </table>
        </form>
      </div>
    </div>

  <?php
  }
    include 'templates/footer.php';
  ?>
