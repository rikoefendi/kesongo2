<?php

  class insert
  {

    private $_db;

    function __construct()
    {
      $this->_db = Database::instance();
    }

    public function tambah_stok($fields = array())
    {
      if( $a = $this->_db->insert($fields, "barang")) return true; else return false;
      die($a);
    }

  }


?>
