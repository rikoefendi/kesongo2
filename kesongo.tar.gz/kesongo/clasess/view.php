<?php

  class view
  {

    private $_db;
    function __construct()
    {
      $this->_db = Database::instance();
    }

    public function get_items()
    {
      if($items = $this->_db->view("items")){
        return $items;
      }else{
        return false;
      }
    }
    public function get_data($action='')
    {

      if($row = $this->_db->view("barang",$action)){
        if(empty($row)){
          echo "data kosong";
        }else{
          return $row;
        }
      }else{
        return false;
      }

    }

  }


?>
