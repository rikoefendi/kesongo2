<?php

  class update
  {

    private $_db;

    public function __construct()
    {
      if($this->_db = Database::instance()) return true; else return false;
    }

    public function update_barang($field = array(), $id)
    {
      if($this->_db->update("barang",$field, $id)) return true; else return false;
    }

  }


?>
