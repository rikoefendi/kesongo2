<?php

  class delete
  {

    private $_db;

    public function __construct()
    {
      if($this->_db = Database::instance()) return true; else return false;
    }

    public function delete_barang($id)
    {
      if($this->_db->delete("barang", "id_barang", $id)) return true; else return false;
    }
  }


?>
