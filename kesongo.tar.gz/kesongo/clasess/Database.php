<?php

  class Database
  {
    private static $_INSTANCE = null;
    private $mysql,
            $HOST       = 'localhost',
            $USER       = 'root',
            $PASS       = '',
            $DBNAME     = 'Kesongo';

    function __construct()
    {
      $this->mysqli = new mysqli($this->HOST, $this->USER, $this->PASS, $this->DBNAME);
    }

    public static function instance()
    {
      if(!isset(self::$_INSTANCE)){
        self::$_INSTANCE = new Database();
      }
      return self::$_INSTANCE;
    }

    public function view($table,$action='')
    {

      $query = "SELECT * FROM $table $action";
      $result = $this->mysqli->query($query);
        while ($row = $result->fetch_object()) {
          $results[] = $row;
        }
        return $results;

    }
    public function insert($fields, $table)
    {
      $col = implode(',', array_keys($fields));
      $a=array();
      $i=1;
      foreach ($fields as $key => $value) {
        $a[$i] = "'".$value."'";
        $i++;
      }
      $value = implode(',', $a);
      $query = "INSERT INTO $table ($col) VALUES ($value)";
      if($b = $this->mysqli->multi_query($query))return true; else return false;
    }

    public function delete($table, $field, $id)
    {
      $query = "DELETE FROM $table WHERE $field = $id";
      if($this->mysqli->multi_query($query)) return true; else return false;
    }

    public function update($tabel, $field, $id)
    {
      $setarray = array();
      $i = 1;
      foreach ($field as $key => $value) {
        $setarray[$i] = $key. "='".$value."'";
        $i++;
      }
      $set = implode(', ', $setarray);
      $query = "UPDATE $tabel SET $field WHERE id_items = $id";
      var_dump($query);
      die();
    }

  }

?>
