<?php

  class rupiah
  {

    public static function rp($nilai, $pecahan=0)
    {
      return number_format($nilai, $pecahan, ',', '.');
    }
  }


?>
