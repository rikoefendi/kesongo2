<?php

  include'core/init.php';
  $db = Database::instance();
  $view = new view();
  if(Input::get('delete')){
    $id = Input::get('chk');
    $jml = count(Input::get('chk'));
    if($jml>0){
      for($i=0; $i<$jml; $i++){
        $ib = $id[$i];
        $delete->delete_barang($ib);
      }
    }
  }
  include'templates/header.php';

?>

    <div class="konten">
      <div class="table">

        <div class="tambah_stok" id="tambahstok">
          <div class="for-form">
              <a href="#close" class="cp">X</a>
            <form action="tambah-stok.php" method="post">
              <div class="input">
                <p><b>Isi Jumlah data yang di input</b></p>
                <input type="text" name="for" value="">
                <input type="submit" name="subfor" value="GO">
              </div>
            </form>
          </div>
        </div>
        <h2>Stok Barang</h2>
        <div class="add">
          <a href="#tambahstok" title="Tambah Stok"><img src="img/file_add.png" alt="">TambahStok</a>
        </div>
        <form class="form" name="frm" method="post">
          <table class="container">
            <tr class="table-row heading">
              <th class="col c"><input type="checkbox" class="select-all" /></th>
              <th class="col k">Kode Barang</th>
              <th class="col i">Item</th>
              <th class="col m">Merk/Nama</th>
              <th class="col h">H Beli(Rp)</th>
              <th class="col h">H Jual(Rp)</th>
              <th class="col h">Laba(Rp)</th>
              <th class="col s">S Awal</th>
              <th class="col s">S Beli</th>
              <th class="col s">S Jual</th>
              <th class="col s">S Akhir</th>
              <th class="col a">Aset Toko</th>
              <th class="col t">Status</th>
              <th class="hide"></th>
            </tr>
            <?php
            $items = $view->get_items();
            foreach ($items as $key => $i){
              $row = $view->get_data("WHERE id_items=$i->id_items");
            foreach ($row as $a){
            ?>
            <tr>
              <th class="col c"><input type="checkbox" name="chk[]" class="chk-box" value="<?php echo $a->id_barang; ?>"></th>
              <td class="col"><?php echo $a->kode_barang; ?></td>
              <td class="col ver" rowspan=""><?php echo $i->nama_items; ?></td>
              <td class="col"><?php echo $a->nama_barang; ?></td>
              <td class="col"><?php echo rupiah::rp($a->h_beli,2); ?></td>
              <td class="col"><?php echo rupiah::rp($a->h_jual,2); ?></td>
              <td class="col"><?php echo rupiah::rp($a->laba,2); ?></td>
              <td class="col"><?php echo rupiah::rp($a->s_awal,2); ?></td>
              <td class="col"><?php echo $a->s_beli; ?></td>
              <td class="col"><?php echo $a->s_jual; ?></td>
              <td class="col"><?php echo $b=$a->s_awal+$a->s_beli-$a->s_jual; ?></td>
              <td class="col"><?php echo rupiah::rp($a->aset_toko,2); ?></td>
              <td class="col"><?php if($b>= 1){echo"ready";}else{echo "kosong";} ?></td>
              <td class="aksi">
                <a href=""><i class="fa fa-pencil-square-o"></i>Edit</a>
                <a href=""><i class="fa fa-minus-circle">Delete</i></a>

              </td>
            </tr>
          <?php }} ?>
          <tr>
            <td rowspan="7">
              <input type="submit" name="delete" value="Delete">
              <img src="img/edit.png" alt="" onclick="update_records();">
            </td>
          </tr>
        </table>
        </form>
      </div>
    </div>




<?php

  include'templates/footer.php';

?>
