<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Kesongo Multi Utama</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow" rel="stylesheet">
    <script src="assets/js/jquery.js" type="text/javascript"></script>
    <script src="assets/js/js-script.js" type="text/javascript"></script>
  </head>
  <body>
    <div class="navbar">
      <div class="header">
        <nav class="nav-horizontal">
          <div id="brand">
            <i class="fa fa-laptop"></i>Kesongo Multi Utama
          </div>
          <ul class="account">
            <li><a href=""><i class="fa fa-user"></i>User</a><i style="color:#337ab7; padding-left:5px;" onclick="myFunction('user');"class="fa fa-caret-square-o-down"></i></li>
              <ul class="close user" id="user">
                <li><a href=""><i class="fa fa-cog"></i>Edit</a></li>
                <li><a href=""><i class="fa fa-sign-out"></i>Logout</a></li>
              </ul>
          </ul>
        </nav>
      </div>
      <div class="clear" style="clear:both;"></div>
      <nav class="nav-vertical">
        <ul class="menu">
          <li><a href=""><i class="fa fa-tachometer"></i>Dashboard</a></li>
          <li><a href=""><i class="fa fa-archive"></i>Stok Barang</a></li>
          <li onclick="myFunction('Demo1')"><a><i class="fa fa-bug"></i>Laporan</a></li>
            <ul id="Demo1" class="close">
              <li><a href=""><i class="fa fa-buysellads"></i>Penjualan</a></li>
              <li><a href=""><i class="fa fa-shopping-bag"></i>Belanja</a></li>
            </ul>
          <li><a href=""><i class="fa fa-trash"></i>Trash</a></li>
        </ul>
      </nav>
    </div>
