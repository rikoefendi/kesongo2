<script>
  function myFunction(id) {
      var x = document.getElementById(id);
      if (x.className.indexOf("open") == -1) {
          x.className += " open";
      } else {
          x.className = x.className.replace(" open", "");
      }
  }
</script>

</body>
</html>
